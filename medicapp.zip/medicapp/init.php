<?php
/**
 * Plugin initialization file.
 *
 * @package     Medicapp
 * @author      Medicapp <hola@medicapp.com.ar>
 * @link        http://www.medicapp.com.ar/
 * @copyright   2016 Medicapp
 * @since       1.0
 */
// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
    die;
}

if ( ! function_exists( 'mapp_load_autoloader' ) ) :
    add_action( 'mapp_plugin_init', 'mapp_load_autoloader');
    /**
     * Call to autoloader class
     *
     * @since 1.0
     */
    function mapp_load_autoloader() {
        // Load autoloader files.
        require plugin_dir_path( __FILE__ ) . 'autoloader/class-autoloader.php';
        require plugin_dir_path( __FILE__ ) . 'autoloader/functions.php';
    }
endif;

if ( ! function_exists( 'mapp_load_textdomain' ) ) :
    /**
     * Load plugin textdomain.
     *
     * @since 1.0
     */
    add_action( 'mapp_plugin_init', 'mapp_load_textdomain');
    function mapp_load_textdomain(){
        load_plugin_textdomain( 'mapp', false , MAPP_FOLDER . '/languages' );
    }
endif;

if ( ! function_exists( 'mapp_plugin_init_admin' ) ) :
    /**
     * Load files inside `admin` folder.
     *
     * @since 1.0
     */
    add_action( 'mapp_plugin_init', 'mapp_plugin_init_admin');
    function mapp_plugin_init_admin() {
	    mapp_autoload( plugin_dir_path( __FILE__ ) . 'admin' );
    }
endif;

if ( ! function_exists( 'mapp_plugin_init_includes' ) ) :
    /**
     * Load files inside `includes` folder.
     *
     * @since 1.0
     */
    add_action( 'mapp_plugin_init', 'mapp_plugin_init_includes');
    function mapp_plugin_init_includes(){
        mapp_autoload( plugin_dir_path( __FILE__ ) . 'includes', '', array());
    }
endif;

if ( ! function_exists( 'mapp_plugin_init_public' ) ) :
    /**
     * Load files inside `public` folder.
     *
     * @since 1.0
     */
    add_action( 'mapp_plugin_init', 'mapp_plugin_init_public');
    function mapp_plugin_init_public(){
        mapp_autoload( plugin_dir_path( __FILE__ ) . 'public' );
    }
endif;

do_action('mapp_plugin_init');




