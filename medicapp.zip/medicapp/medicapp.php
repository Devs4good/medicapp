<?php
/**
 * Plugin main file.
 *
 * Plugin Name: 1_ Medicapp
 * Plugin URI: 	http://medicaoo.com.ar/
 * Description: Sistema para prevenir la automedicación
 * Version:     1.0
 * Author:      Medicapp
 * Author URI:  http://medicapp.com.ar
 * Domain Path: /languages
 * Text Domain: sai
 *
 * @package     medicapp
 * @author      Medicapp <hola@medicapp.com.ar>
 * @link        http://www.medicapp.com.ar/
 * @copyright   2016 Medicapp
 * @since       1.0
 */
// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}


/**
 * DEFINE CONSTANTS
 */

define( 'MAPP_VERSION', '1.0|' );
define( 'MAPP_MAIN_FILE', __FILE__ );


define( 'MAPP_PATH', dirname( __FILE__ ) );
define( 'MAPP_FOLDER', basename( MAPP_PATH ) );
define( 'MAPP_URL', plugins_url() . '/' . MAPP_FOLDER );

define( 'MAPP_PATH_ADMIN', dirname( __FILE__ ) . '/admin' );
define( 'MAPP_URL_ADMIN', MAPP_URL . '/admin' );
define( 'MAPP_PATH_PUBLIC', dirname( __FILE__ ) . '/public' );
define( 'MAPP_URL_PUBLIC', MAPP_URL . '/public' );
define( 'MAPP_PATH_INCLUDES', dirname( __FILE__ ) . '/includes' );
define( 'MAPP_URL_INCLUDES', MAPP_URL . '/includes' );
define( 'MAPP_PATH_IMAGES', dirname( __FILE__ ) . '/images' );
define( 'MAPP_URL_IMAGES', MAPP_URL . '/images' );






if ( ! function_exists( 'mapp_plugin_load' ) ) :
add_action( 'mapp_plugin_load', 'mapp_plugin_load' );
/**
 * Load plugin initialization process.
 *
 * @since 1.0
 */
function mapp_plugin_load() {
	/**
	 * @hook mapp_plugin_init
	 *
	 * Hook here to disable this plugin's functionality.
	 */
	if ( apply_filters( 'mapp_plugin_init', true ) ) {
		require_once plugin_dir_path( __FILE__ ) . 'init.php';
	}
}
endif;

/**
 * @hook mapp_plugin_load
 *
 * Hook here to load plugin functionality.
 *
 * Hooked here:
 * @see mapp_plugin_load()
 */
do_action( 'mapp_plugin_load' );
