<?php
/**
 * Manage taxonomies.
 *
 * @package     SAI
 * @author      Pablo Capello <pablo@aureaagency.com>
 * @link        http://www.sistemamapp.com.ar/
 * @copyright   2016 SAI
 * @since       1.0
 */
// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
    die;
}
    if (!function_exists('mapp_register_body_part_taxonomy')) :
        add_action('init', 'mapp_register_body_part_taxonomy');
        /**
         * Register "body_part" taxonomy.
         *
         * @since 1.0
         */
        function mapp_register_body_part_taxonomy()
        {
            $tax_labels = array(
                'name' => __('Body Parts', 'mapp'),
                'singular_name' => __('Body Part', 'mapp'),
                'search_items' => __('Search body part', 'mapp'),
                'all_items' => __('All body parts', 'mapp'),
                'parent_item' => __('Parent body part', 'mapp'),
                'parent_item_colon' => __('Parent body part:', 'mapp'),
                'edit_item' => __('Edit body part', 'mapp'),
                'update_item' => __('Update body part', 'mapp'),
                'add_new_item' => __('New body part', 'mapp'),
                'new_item_name' => __('New body part name', 'mapp'),
                'menu_name' => __('Body Part', 'mapp')
            );

            $tax_args = array(
                'hierarchical' => true,
                'labels' => $tax_labels,
                'show_ui' => true,
                'show_admin_column' => true,
                'query_var' => true,
                'rewrite' => array('slug' => 'body-part'),
            );
            register_taxonomy('body-part', array('specialty'), $tax_args);
        }
    endif;


if (!function_exists('mapp_register_tip_tag_taxonomy')) :
    add_action('init', 'mapp_register_tip_tag_taxonomy');
    /**
     * Register "Tip tag" taxonomy.
     *
     * @since 1.0
     */
    function mapp_register_tip_tag_taxonomy()
    {
        $tax_labels = array(
            'name' => __('Tip tags', 'mapp'),
            'singular_name' => __('Tip tag', 'mapp'),
            'search_items' => __('Search tip tag', 'mapp'),
            'all_items' => __('All tip tags', 'mapp'),
            'parent_item' => __('Parent tip tags', 'mapp'),
            'parent_item_colon' => __('Parent tip tag:', 'mapp'),
            'edit_item' => __('Edit tip tag', 'mapp'),
            'update_item' => __('Update tip tag', 'mapp'),
            'add_new_item' => __('New tip tag', 'mapp'),
            'new_item_name' => __('New tip tag name', 'mapp'),
            'menu_name' => __('Tip tags', 'mapp')
        );

        $tax_args = array(
            'hierarchical' => true,
            'labels' => $tax_labels,
            'show_ui' => true,
            'show_admin_column' => true,
            'query_var' => true,
            'rewrite' => array('slug' => 'tip-tag'),
        );
        register_taxonomy('tip-tag', array('tip'), $tax_args);
    }
endif;
