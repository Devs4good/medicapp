<?php
/**
 * Manage post type.
 *
 * @package     SAI
 * @author      Pablo Capello <pablo@aureaagency.com>
 * @link        http://www.sistemamapp.com.ar/
 * @copyright   2016 SAI
 * @since       1.0
 */
// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
    die;
}

    if ( ! function_exists( 'mapp_create_specialty_post_type' ) ) :
        add_action( 'init', 'mapp_create_specialty_post_type' );
        /**
         * Initialize "specialty" post type.
         *
         * @since 1.0
         */
        function mapp_create_specialty_post_type() {
            $cpt_labels = array(
                'name' 					=> __( 'Specialties', 'mapp' ),
                'singular_name' 		=> __( 'Specialties', 'mapp' ),
                'add_new' 				=> __( 'New specialty', 'mapp' ),
                'add_new_item' 			=> __( 'Add new specialty', 'mapp' ),
                'edit_item' 			=> __( 'Edit specialty', 'mapp' ),
                'new_item' 				=> __( 'New specialty', 'mapp' ),
                'all_items' 			=> __( 'All specialties', 'mapp' ),
                'view_item' 			=> __( 'View specialty', 'mapp' ),
                'search_items' 			=> __( 'Search specialties', 'mapp' ),
                'not_found' 			=>  __( 'No specialties found', 'mapp' ),
                'not_found_in_trash'    => __( 'No specialties found in Trash', 'mapp' ),
                'parent_item_colon'     => '',
                'menu_name' 			=> __( 'Specialties', 'mapp' )
            );
            $cpt_args = array(
                'labels' 				=> $cpt_labels,
                'public'				=> true,
                'publicly_queryable'	=> true,
                'show_ui' 				=> true,
                'show_in_menu' 			=> true,
                'show_in_rest' 			=> true,
                'show_in_nav_menus' 	=> true,
                'query_var' 			=> true,
                'rewrite' 				=> array('slug' => __( 'specialty', 'mapp' )),
                'has_archive' 			=> true,
                'hierarchical' 			=> false,
                'menu_icon' 			=> 'dashicons-heart',
                'supports' 				=> array( 'title','editor'),
                'map_meta_cap'          => true
            );
            register_post_type('specialty',$cpt_args);
        }
    endif;


if ( ! function_exists( 'mapp_create_tip_post_type' ) ) :
    add_action( 'init', 'mapp_create_tip_post_type' );
    /**
     * Initialize "tip" post type.
     *
     * @since 1.0
     */
    function mapp_create_tip_post_type() {
        $cpt_labels = array(
            'name' 					=> __( 'Tips', 'mapp' ),
            'singular_name' 		=> __( 'Tips', 'mapp' ),
            'add_new' 				=> __( 'New tip', 'mapp' ),
            'add_new_item' 			=> __( 'Add new tip', 'mapp' ),
            'edit_item' 			=> __( 'Edit tip', 'mapp' ),
            'new_item' 				=> __( 'New tip', 'mapp' ),
            'all_items' 			=> __( 'All tips', 'mapp' ),
            'view_item' 			=> __( 'View tip', 'mapp' ),
            'search_items' 			=> __( 'Search tips', 'mapp' ),
            'not_found' 			=>  __( 'No tips found', 'mapp' ),
            'not_found_in_trash'    => __( 'No tips found in Trash', 'mapp' ),
            'parent_item_colon'     => '',
            'menu_name' 			=> __( 'Tips', 'mapp' )
        );
        $cpt_args = array(
            'labels' 				=> $cpt_labels,
            'public'				=> true,
            'publicly_queryable'	=> true,
            'show_ui' 				=> true,
            'show_in_menu' 			=> true,
            'show_in_rest' 			=> true,
            'show_in_nav_menus' 	=> true,
            'query_var' 			=> true,
            'rewrite' 				=> array('slug' => __( 'tip', 'mapp' )),
            'has_archive' 			=> true,
            'hierarchical' 			=> false,
            'menu_icon' 			=> 'dashicons-lightbulb',
            'supports' 				=> array( 'title','editor'),
            'map_meta_cap'          => true
        );
        register_post_type('tip',$cpt_args);
    }
endif;
