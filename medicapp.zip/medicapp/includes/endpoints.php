<?php
/**
 * Manage post type.
 *
 * @package     SAI
 * @author      Pablo Capello <pablo@aureaagency.com>
 * @link        http://www.sistemamapp.com.ar/
 * @copyright   2016 SAI
 * @since       1.0
 */
// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
    die;
}


function rest_tip_content( $data ) {

    $args = array(
        'posts_per_page' => 1,
        'orderby' => 'desc',
        'post_type' => 'tip',
        'post_status' => 'publish'
    );
    $tips = get_posts( $args );


    return $tips[0]->post_content;
}

add_action( 'rest_api_init', function () {
    register_rest_route( 'medicapp/v1', '/tip/', array(
        'methods' => 'GET',
        'callback' => 'rest_tip_content',
    ) );
} );



function rest_specialty_filter ( WP_REST_Request $request ) {

    $param = $request['id'];


    /*
    echo '<pre>';
    var_dump($data);
    //var_dump($data->params->URL->id);
    echo '</pre>';
    wp_die();
    $posts = get_posts();
    */

    $args = array(
        'orderby' => 'asc',
        'post_type' => '',
        'post_status' => 'publish',
        'tax_query' => array(
            'taxonomy' => '',
            'field' => 'ID',
            'terms' => $param,
            'operator' => 'IN'
        )
    );
    $specialties = get_posts( $args );

    $args = array(
        'post_type' => 'specialty',
        'tax_query' => array(
            array(
                'taxonomy' => 'body-part',
                'field'    => 'term_id',
                'terms'    => $param,
            ),
        ),
    );

    $output = '';

    // The Query
    $specialties = new WP_Query( $args );

    // The Loop
    if ( $specialties->have_posts() ) {
        while ( $specialties->have_posts() ) {
            $specialties->the_post();
            $output = get_the_title();
        }
        /* Restore original Post Data */
        wp_reset_postdata();
    } else {
        // no posts found
        $output = 'void';
    }
    return $output;
}

add_action( 'rest_api_init', function () {
    register_rest_route( 'medicapp/v1', '/specialty/(?P<id>\d+)', array(
        'methods' => 'GET',
        'callback' => 'rest_specialty_filter',
    ) );
} );