<?php
/**
 * This file contains general functions that allow interactions with
 * this helper in an easier way.
 *
 * @package     Medicapp
 * @author      Medicapp <hola@medicapp.com.ar>
 * @link        http://www.medicapp.com.ar/
 * @copyright   2016 Medicapp
 * @since       1.0
 */
// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Load a given directory recursively.
 *
 * @uses   MAPP_AutoLoader::__construct()
 *
 * @since  1.0
 *
 * @param  string   $path           File or folder to be loaded recursively.
 * @param  string   $root_directory Base folder of main namespace.
 * @param  array    $exclude        List of files and folders to exclude.
 *
 * @return MAPP_AutoLoader
 */
function mapp_autoload( $path, $root_directory = '', array $exclude = null ) {
    return new MAPP_AutoLoader( $path, $root_directory, $exclude );
}

/**
 * Load a list of directories recursively.
 *
 * @uses   mapp_autoload()
 *
 * @since  1.0
 *
 * @param  array    $libraries      List of files or folders to be loaded recursively.
 * @param  string   $root_directory Base folder of main namespace.
 * @param  array    $exclude        List of files and folders to exclude.
 *
 * @return MAPP_AutoLoader
 */
function mapp_autoload_libraries( array $libraries, $root_directory = '', array $exclude = null ) {
	if ( ! empty( $libraries ) ) {
		foreach ( $libraries as $library ) {
			mapp_autoload( $library, $root_directory, $exclude );
		}
	}
}
